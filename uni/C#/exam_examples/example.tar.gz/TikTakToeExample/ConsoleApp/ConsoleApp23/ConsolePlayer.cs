﻿using TikTakToe.Core;

class ConsolePlayer : IPlayer
{
	public string Name { get; }
	public ConsolePlayer(string name)
	{
		Name = name;
	}
	public (int, int) MakeMove(IGameMap gameMap)
	{
		Console.WriteLine($"Player {Name}, enter row and column:");
		while (true)
		{
			string[] parts = Console.ReadLine().Split(' ');
			
			if (parts.Length != 2)
			{
				Console.WriteLine("Invalid input. Enter row and column:");
				continue;
			}

			if (!int.TryParse(parts[0], out int row) || !int.TryParse(parts[1], out int column))
			{
				Console.WriteLine("Invalid input. Enter row and column:");
				continue;
			}

			if (row < 0 || row >= gameMap.Rows || column < 0 || column >= gameMap.Columns)
			{
				Console.WriteLine("Invalid input. Enter row and column:");
				continue;
			}

			if (gameMap[row, column] is null)
			{
				return (row, column);
			}
			else
			{
				Console.WriteLine("Invalid input. Enter row and column:");
			}
		}
	}
}