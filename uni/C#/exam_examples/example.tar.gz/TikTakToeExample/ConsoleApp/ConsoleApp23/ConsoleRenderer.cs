﻿using TikTakToe.Core;

class ConsoleRenderer : IGameRenderer
{
	public void Render(IGameMap gameMap, int lastRow, int lastColumn)
	{
		Console.Clear();
		for (int i = 0; i < gameMap.Rows; i++)
		{
			for (int j = 0; j < gameMap.Columns; j++)
			{
				var player = gameMap[i, j];
				if (player == null)
				{
					Console.Write(" ");
				}
				else
				{
					Console.Write(player.Name[0]);
				}
			}
			Console.WriteLine();
		}
	}
}
