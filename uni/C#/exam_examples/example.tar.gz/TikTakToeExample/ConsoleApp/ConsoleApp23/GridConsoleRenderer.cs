﻿using TikTakToe.Core;

class GridConsoleRenderer : IGameRenderer
{
	// |X|O|X|
	// |O|X|O|
	// |X|O|X|
	public void Render(IGameMap gameMap, int lastRow, int lastColumn)
	{
		Console.Clear();
		for (int i = 0; i < gameMap.Rows; i++)
		{
			for (int j = 0; j < gameMap.Columns; j++)
			{
				var player = gameMap[i, j];
				if (player == null)
				{
					Console.Write(" ");
				}
				else
				{
					Console.Write(player.Name[0]);
				}
				if (j < gameMap.Columns - 1)
				{
					Console.Write("|");
				}
			}
			Console.WriteLine();
			if (i < gameMap.Rows - 1)
			{
				for (int j = 0; j < gameMap.Columns; j++)
				{
					Console.Write("-");
					if (j < gameMap.Columns - 1)
					{
						Console.Write("+");
					}
				}
				Console.WriteLine();
			}
		}
	}
}