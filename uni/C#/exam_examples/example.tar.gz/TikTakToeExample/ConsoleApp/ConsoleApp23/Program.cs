﻿using TikTakToe;
using TikTakToe.Classic;
using TikTakToe.Core;
using TikTakToe.FreeGame;

IPlayer[] players =
{
	new RandomPlayer("A Player"),
	new RandomPlayer("B Player"),
	new RandomPlayer("C Player"),
	new RandomPlayer("D Player"),
	new RandomPlayer("E Player"),
	new RandomPlayer("F Player"),
	new RandomPlayer("G Player"),
	new ConsolePlayer("X Player"),
};
IGameEndChecker gameEndChecker = new ElementsRowEndGameChecker(4);
IGameRenderer gameRenderer = new GridConsoleRenderer();
FreeGameLogic game = new FreeGameLogic(players, gameEndChecker, gameRenderer, 20, 20, false);

game.StartGame();

Console.WriteLine("Game ended");
Console.WriteLine(game.Winner is null ? "Draw" : $"Winner: {game.Winner.Name}");
