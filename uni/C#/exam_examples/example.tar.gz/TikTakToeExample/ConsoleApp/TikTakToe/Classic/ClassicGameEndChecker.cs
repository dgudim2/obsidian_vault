﻿using TikTakToe.Core;

namespace TikTakToe.Classic
{
	internal class ClassicGameEndChecker : IGameEndChecker
	{
		private IPlayer? _winner;

		public IPlayer? GetWinner(IGameMap gameMap)
		{
			if (_winner is null)
			{
				IsGameEnded(gameMap);
			}

			return _winner;
		}

		public bool IsGameEnded(IGameMap gameMap)
		{
			if (gameMap.Columns != 3 || gameMap.Rows != 3)
			{
				throw new ArgumentException("Classic game should have 3x3 map");
			}

			if (_winner is not null)
			{
				return true;
			}

			IPlayer? winner = CheckRows(gameMap);
			if (winner is not null)
			{
				_winner = winner;
				return true;
			}

			winner = CheckColumns(gameMap);
			if (winner is not null)
			{
				_winner = winner;
				return true;
			}

			winner = CheckDiagonals(gameMap);
			if (winner is not null)
			{
				_winner = winner;
				return true;
			}

			for (int i = 0; i < gameMap.Rows; i++)
			{
				for (int j = 0; j < gameMap.Columns; j++)
				{
					if (gameMap[i, j] is null)
					{
						return false;
					}
				}
			}

			return true;
		}

		private IPlayer? CheckRows(IGameMap gameMap)
		{
			for (int i = 0; i < gameMap.Rows; i++)
			{
				if (gameMap[i, 0] == gameMap[i, 1] && gameMap[i, 1] == gameMap[i, 2])
				{
					return gameMap[i, 0];
				}
			}
			return null;
		}

		private IPlayer? CheckColumns(IGameMap gameMap)
		{
			for (int i = 0; i < gameMap.Columns; i++)
			{
				if (gameMap[0, i] == gameMap[1, i] && gameMap[1, i] == gameMap[2, i])
				{
					return gameMap[0, i];
				}
			}
			return null;
		}

		private IPlayer? CheckDiagonals(IGameMap gameMap)
		{
			if (gameMap[0, 0] == gameMap[1, 1] && gameMap[1, 1] == gameMap[2, 2])
			{
				return gameMap[0, 0];
			}
			if (gameMap[0, 2] == gameMap[1, 1] && gameMap[1, 1] == gameMap[2, 0])
			{
				return gameMap[0, 2];
			}
			return null;
		}
	}
}
