﻿using TikTakToe.Core;

namespace TikTakToe.Classic
{
	public class ClassicGameLogic : GameLogicBase
	{
		private GameMap _map;

		public ClassicGameLogic(IPlayer[] players,
								IGameRenderer gameRenderer)
			: base(players, new GameMap(3, 3), new ClassicGameEndChecker(), gameRenderer)
		{
			if (players.Length != 2)
			{
				throw new ArgumentException("Classic game should have exactly 2 players");
			}

			_map = (GameMap)GameMap;
		}

		public void StartGame()
		{
			int currentPlayerIndex = 0;
			IPlayer currentPlayer = Players[currentPlayerIndex];

			while (!IsGameEnd)
			{
				(int row, int column) = currentPlayer.MakeMove(GameMap);
				if (_map[row, column] != null)
				{
					throw new InvalidOperationException("Cell is already occupied");
				}
				_map[row, column] = currentPlayer;
				GameRenderer.Render(GameMap, row, column);
				currentPlayerIndex = (currentPlayerIndex + 1) % Players.Length;
				currentPlayer = Players[currentPlayerIndex];
			}
		}
	}
}
