﻿namespace TikTakToe.Core
{
	public abstract class GameLogicBase
	{
		public IPlayer? Winner => GameEndChecker.GetWinner(GameMap);
		public bool IsGameEnd => GameEndChecker.IsGameEnded(GameMap);

		internal protected IPlayer[] Players { get; private set; }
		internal protected IGameMap GameMap { get; private set; }
		internal protected IGameEndChecker GameEndChecker { get; private set; }
		internal protected IGameRenderer GameRenderer { get; private set; }

		public GameLogicBase(	IPlayer[] players,
								IGameMap gameMap,
								IGameEndChecker gameEndChecker,
								IGameRenderer gameRenderer)
		{
			Players = players;
			GameMap = gameMap;
			GameEndChecker = gameEndChecker;
			GameRenderer = gameRenderer;
		}
	}
}
