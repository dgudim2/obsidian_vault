﻿namespace TikTakToe.Core
{
	public interface IGameEndChecker
	{
		bool IsGameEnded(IGameMap gameMap);
		IPlayer? GetWinner(IGameMap gameMap);
	}
}
