﻿namespace TikTakToe.Core
{
	public interface IGameMap
	{
		int Rows { get; }
		int Columns { get; }
		IPlayer? this[int row, int column] { get; }
	}
}
