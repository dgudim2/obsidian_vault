﻿namespace TikTakToe.Core
{
	public interface IGameRenderer
	{
		void Render(IGameMap gameMap, int lastRow, int lastColumn);
	}
}
