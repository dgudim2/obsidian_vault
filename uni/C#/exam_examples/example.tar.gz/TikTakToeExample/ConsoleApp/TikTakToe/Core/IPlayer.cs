﻿namespace TikTakToe.Core
{
	public interface IPlayer
	{
		string Name { get; }
		(int row, int column) MakeMove(IGameMap gameMap);
	}
}
