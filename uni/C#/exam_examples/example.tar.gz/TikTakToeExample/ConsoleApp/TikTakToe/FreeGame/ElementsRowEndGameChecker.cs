﻿using TikTakToe.Core;

namespace TikTakToe.FreeGame
{
	public class ElementsRowEndGameChecker : IGameEndChecker
	{
		private bool _isGameEnded = false;
		private IPlayer? _winner;
		private int _elementsInRowToWin;

		public ElementsRowEndGameChecker(int elementsInRowToWin)
		{
			_elementsInRowToWin = elementsInRowToWin;
		}


		public IPlayer? GetWinner(IGameMap gameMap)
		{
			if (!_isGameEnded)
			{
				return null;
			}

			return _winner;
		}

		public bool IsGameEnded(IGameMap gameMap)
		{
			if (_isGameEnded)
			{
				return true;
			}

			for (int i = 0; i < gameMap.Rows - _elementsInRowToWin; i++)
			{
				for (int j = 0; j < gameMap.Columns - _elementsInRowToWin; j++)
				{
					if (gameMap[i, j] is null)
						continue;

					IPlayer player = gameMap[i, j]!;
					if (RecursiveCheck(player, gameMap, 1, i, j, 1, 0) ||
						RecursiveCheck(player, gameMap, 1, i, j, 0, 1) ||
						RecursiveCheck(player, gameMap, 1, i, j, 1, 1))
					{
						_winner = player;
						_isGameEnded = true;
						return true;
					}
				}
			}

			return false;
		}

		private bool RecursiveCheck(IPlayer value, IGameMap gameMap, int step, int row, int column, int rowStep, int columnStep)
		{
			if (value != gameMap[row, column])
			{
				return false;
			}

			if (step == _elementsInRowToWin)
			{
				return true;
			}

			return RecursiveCheck(value, gameMap, step + 1, row + rowStep, column + columnStep, rowStep, columnStep);
		}
	}
}
