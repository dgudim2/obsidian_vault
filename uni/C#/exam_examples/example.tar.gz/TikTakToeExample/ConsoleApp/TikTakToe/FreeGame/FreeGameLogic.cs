﻿using TikTakToe.Core;

namespace TikTakToe.FreeGame
{
	public class FreeGameLogic : GameLogicBase
	{
		private GameMap _map;
		private bool _canOverrideMap;

		public FreeGameLogic(	IPlayer[] players,
								IGameEndChecker gameEndChecker,
								IGameRenderer gameRenderer,
								int rows,
								int columns,
								bool canOverrideMap = false)
			: base(players, new GameMap(rows, columns) , gameEndChecker, gameRenderer)
		{
			_map = (GameMap)GameMap;
			_canOverrideMap = canOverrideMap;
		}

		public void StartGame()
		{
			int currentPlayerIndex = 0;
			IPlayer currentPlayer = Players[currentPlayerIndex];

			while (!IsGameEnd)
			{
				(int row, int column) = currentPlayer.MakeMove(GameMap);
				if (!_canOverrideMap && _map[row, column] != null)
				{
					throw new InvalidOperationException("Cell is already occupied");
				}
				_map[row, column] = currentPlayer;
				GameRenderer.Render(GameMap, row, column);
				currentPlayerIndex = (currentPlayerIndex + 1) % Players.Length;
				currentPlayer = Players[currentPlayerIndex];
			}
		}
	}
}
