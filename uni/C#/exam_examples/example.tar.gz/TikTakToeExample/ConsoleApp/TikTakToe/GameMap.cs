﻿namespace TikTakToe.Core
{
	internal class GameMap : IGameMap
	{
		public int Rows { get; private set; }
		public int Columns { get; private set; }

		public IPlayer? this[int row, int column]
		{
			get => _map[row, column];
			set => _map[row, column] = value;
		}

		private IPlayer?[,] _map;

		public GameMap(int rows, int columns)
		{
			Rows = rows;
			Columns = columns;

			_map = new IPlayer?[rows, columns];
		}
	}
}
