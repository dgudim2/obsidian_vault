﻿using TikTakToe.Core;

namespace TikTakToe
{
	public class RandomPlayer : IPlayer
	{
		public string Name { get; private set; }

		public (int row, int column) MakeMove(IGameMap gameMap)
		{
			Random random = new Random();
			while (true)
			{
				var row = random.Next(gameMap.Rows);
				var column = random.Next(gameMap.Columns);
				if (gameMap[row, column] is null)
				{
					Thread.Sleep(500);
					return (row, column);
				}
			}
		}

		public RandomPlayer(string name)
		{
			Name = name;
		}
	}
}
