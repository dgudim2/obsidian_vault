package com.cloud.bookclient.controller;

import com.cloud.bookclient.model.BookResponseDto;
import com.cloud.bookclient.service.BookClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/client")
public class LoadBalancerController {
    private final BookClientService bookClientService;

    @Autowired
    public LoadBalancerController(BookClientService bookClientService) {
        this.bookClientService = bookClientService;
    }

    @GetMapping("/books")
    public List<BookResponseDto> getAllBooks() {
        return bookClientService.getAllBooks();
    }

    @GetMapping("/books/{id}")
    public BookResponseDto getBook(@PathVariable Long id) {
        return bookClientService.getBook(id);
    }

    @GetMapping("/server-instance")
    public String getServerInstance() {
        return bookClientService.getServerInstanceInfo();
    }

    @GetMapping("/test-load-balancing")
    public List<String> testLoadBalancing() {
        List<String> responses = new ArrayList<>();

        for (int i = 0; i < 500; i++) {
            String response = bookClientService.getServerInstanceInfo();
            responses.add("Request " + (i+1) + ": " + response);
        }

        return responses;
    }
}
