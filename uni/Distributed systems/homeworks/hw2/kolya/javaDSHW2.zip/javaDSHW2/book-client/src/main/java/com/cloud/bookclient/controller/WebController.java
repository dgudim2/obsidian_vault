package com.cloud.bookclient.controller;

import com.cloud.bookclient.service.BookClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class WebController {

    private final BookClientService bookClientService;

    @Autowired
    public WebController(BookClientService bookClientService) {
        this.bookClientService = bookClientService;
    }

    @GetMapping("/")
    public String home(Model model) {
        List<String> responses = new ArrayList<>();

        for (int i = 0; i < 1; i++) {
            String response = bookClientService.getServerInstanceInfo();
            responses.add(response);
        }

        model.addAttribute("responses", responses);
        model.addAttribute("books", bookClientService.getAllBooks());

        return "index";
    }
}
