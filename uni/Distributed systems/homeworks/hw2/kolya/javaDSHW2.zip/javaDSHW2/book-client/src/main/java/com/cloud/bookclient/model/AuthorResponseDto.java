package com.cloud.bookclient.model;

import lombok.*;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class AuthorResponseDto implements Serializable {
    private Long id;
    private String fistName;
    private String middleName;
    private String lastName;

    public String getFullName() {
        StringBuilder fullName = new StringBuilder(fistName);
        if (middleName != null && !middleName.isEmpty()) {
            fullName.append(" ").append(middleName);
        }
        fullName.append(" ").append(lastName);
        return fullName.toString();
    }

    public Long getId() {
        return id;
    }

    public String getFistName() {
        return fistName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getLastName() {
        return lastName;
    }
}
