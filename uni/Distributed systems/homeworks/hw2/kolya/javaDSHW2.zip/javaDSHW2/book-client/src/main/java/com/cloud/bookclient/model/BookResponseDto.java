package com.cloud.bookclient.model;

import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class BookResponseDto implements Serializable {
    private Long id;
    private String title;
    private List<AuthorResponseDto> authors;
    private List<GenreResponseDto> genres;
    private BigDecimal price;
    private int stock;
    private String coverImageFile;

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public List<AuthorResponseDto> getAuthors() {
        return authors;
    }

    public List<GenreResponseDto> getGenres() {
        return genres;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public int getStock() {
        return stock;
    }

    public String getCoverImageFile() {
        return coverImageFile;
    }
}
