package com.cloud.bookclient.model;

import lombok.*;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class GenreResponseDto implements Serializable {
    private Long id;
    private String genre;

    public Long getId() {
        return id;
    }

    public String getGenre() {
        return genre;
    }
}
