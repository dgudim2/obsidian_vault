package com.cloud.bookclient.service;

import com.cloud.bookclient.model.BookResponseDto;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class BookClientService {

    private final RestTemplate restTemplate;

    public BookClientService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public BookResponseDto getBook(Long id) {
        return restTemplate.getForObject("http://book-microservice/api/books/" + id, BookResponseDto.class);
    }

    public List<BookResponseDto> getAllBooks() {
        ResponseEntity<List<BookResponseDto>> response = restTemplate.exchange(
                "http://book-microservice/api/books",
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<BookResponseDto>>() {}
        );
        return response.getBody();
    }

    public String getServerInstanceInfo() {
        return restTemplate.getForObject("http://book-microservice/instance-info", String.class);
    }
}
