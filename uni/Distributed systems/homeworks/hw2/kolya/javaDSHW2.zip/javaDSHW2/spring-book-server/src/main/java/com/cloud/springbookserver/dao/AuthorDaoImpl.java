package com.cloud.springbookserver.dao;

import com.cloud.springbookserver.dao.interfaces.AuthorDao;
import com.cloud.springbookserver.model.Author;
import com.cloud.springbookserver.repository.AuthorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class AuthorDaoImpl implements AuthorDao {

    private final AuthorRepository authorRepository;

    @Override
    public List<Author> getAll() {
        return authorRepository.findAll();
    }
}
