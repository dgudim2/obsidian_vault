package com.cloud.springbookserver.dao;

import com.cloud.springbookserver.dao.interfaces.BookDao;
import com.cloud.springbookserver.model.Book;
import com.cloud.springbookserver.repository.BookRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class BookDaoImpl implements BookDao {

    private final BookRepository bookRepository;

    @Override
    public Book getById(Long id) {
        return bookRepository.findById(id).orElseThrow();
    }

    @Override
    public List<Book> getAll() {
        return bookRepository.findAll();
    }

    @Override
    public Page<Book> getByKeyWord(String searchTerm, Pageable pageable) {
        return bookRepository.searchBooksByTitleOrAuthorOrGenre(searchTerm, pageable);
    }

}
