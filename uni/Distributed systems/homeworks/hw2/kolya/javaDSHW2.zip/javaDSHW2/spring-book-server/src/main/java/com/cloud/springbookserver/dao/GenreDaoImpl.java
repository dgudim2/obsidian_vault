package com.cloud.springbookserver.dao;

import com.cloud.springbookserver.dao.interfaces.GenreDao;
import com.cloud.springbookserver.model.Genre;
import com.cloud.springbookserver.repository.GenreRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class GenreDaoImpl implements GenreDao {

    private final GenreRepository genreRepository;

    @Override
    public List<Genre> getAll() {
        return genreRepository.findAll();
    }
}
