package com.cloud.springbookserver.dao.interfaces;

import com.cloud.springbookserver.model.Author;

import java.util.List;

public interface AuthorDao {
    List<Author> getAll();
}
