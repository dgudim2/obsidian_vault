package com.cloud.springbookserver.dao.interfaces;

import com.cloud.springbookserver.model.Book;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface BookDao {
    Book getById(Long id);
    List<Book> getAll();
    Page<Book> getByKeyWord(@Param("searchTerm") String searchTerm, Pageable pageable);
}
