package com.cloud.springbookserver.dao.interfaces;

import com.cloud.springbookserver.model.Genre;

import java.util.List;

public interface GenreDao {
    List<Genre> getAll();
}
