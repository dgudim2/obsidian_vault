package com.cloud.springbookserver.repository;

import com.cloud.springbookserver.model.Genre;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GenreRepository extends JpaRepository<Genre, Long> {
}
