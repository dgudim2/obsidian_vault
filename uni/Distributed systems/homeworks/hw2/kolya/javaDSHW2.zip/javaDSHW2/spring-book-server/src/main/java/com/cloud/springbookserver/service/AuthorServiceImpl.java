package com.cloud.springbookserver.service;

import com.cloud.springbookserver.dao.interfaces.AuthorDao;
import com.cloud.springbookserver.dto.response.AuthorResponseDto;
import com.cloud.springbookserver.service.interfaces.AuthorService;
import com.cloud.springbookserver.utils.DtoMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AuthorServiceImpl implements AuthorService {

    private final AuthorDao authorDao;

    @Override
    public List<AuthorResponseDto> getAll() {
        return authorDao.getAll().stream().map(DtoMapper::authorToDto).toList();
    }
}
