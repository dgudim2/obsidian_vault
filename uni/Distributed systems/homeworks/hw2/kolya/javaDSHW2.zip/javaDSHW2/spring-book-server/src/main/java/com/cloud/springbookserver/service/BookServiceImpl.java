package com.cloud.springbookserver.service;

import com.cloud.springbookserver.dao.interfaces.BookDao;
import com.cloud.springbookserver.dto.response.BookResponseDto;
import com.cloud.springbookserver.service.interfaces.BookService;
import com.cloud.springbookserver.utils.DtoMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BookServiceImpl implements BookService {

    private final BookDao bookDao;

    @Override
    public BookResponseDto getById(Long id) {
        return DtoMapper.bookToDto(bookDao.getById(id));
    }

    @Override
    public List<BookResponseDto> getAll() {
        return bookDao.getAll().stream().map(DtoMapper::bookToDto).toList();
    }

    @Override
    public Page<BookResponseDto> getByKeyWord(int pageNum, int pageSize, String searchWord) {
        Pageable pageable = PageRequest.of(pageNum, pageSize);
        return bookDao.getByKeyWord(searchWord, pageable).map(DtoMapper::bookToDto);
    }
}