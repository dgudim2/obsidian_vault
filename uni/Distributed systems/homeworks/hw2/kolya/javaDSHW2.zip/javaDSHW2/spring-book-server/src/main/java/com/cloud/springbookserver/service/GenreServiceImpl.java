package com.cloud.springbookserver.service;

import com.cloud.springbookserver.dao.interfaces.GenreDao;
import com.cloud.springbookserver.dto.response.GenreResponseDto;
import com.cloud.springbookserver.service.interfaces.GenreService;
import com.cloud.springbookserver.utils.DtoMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class GenreServiceImpl implements GenreService {

    private final GenreDao genreDao;

    @Override
    public List<GenreResponseDto> getAll() {
        return genreDao.getAll().stream().map(DtoMapper::genreToDto).toList();
    }
}
