package com.cloud.springbookserver.service.interfaces;

import com.cloud.springbookserver.dto.response.AuthorResponseDto;

import java.util.List;

public interface AuthorService {
    List<AuthorResponseDto> getAll();
}
