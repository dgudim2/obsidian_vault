package com.cloud.springbookserver.service.interfaces;

import com.cloud.springbookserver.dto.response.BookResponseDto;
import org.springframework.data.domain.Page;

import java.util.List;

public interface BookService {
    BookResponseDto getById(Long id);
    List<BookResponseDto> getAll();
    Page<BookResponseDto> getByKeyWord(int pageNum, int pageSize, String searchWord);
}
