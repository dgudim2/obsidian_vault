package com.cloud.springbookserver.service.interfaces;

import com.cloud.springbookserver.dto.response.GenreResponseDto;

import java.util.List;

public interface GenreService {
    List<GenreResponseDto> getAll();
}
