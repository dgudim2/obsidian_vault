package com.springbookserver.model;

public enum SortingOrder {
    ASC,
    DESC
}
