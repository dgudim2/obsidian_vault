document.addEventListener('DOMContentLoaded', () => {
    const basketItems = document.querySelector('#basket ul');

    // Function to remove an item
    const removeItem = (event) => {
        const listItem = event.target.parentElement; // Get the parent <li> element
        basketItems.removeChild(listItem); // Remove the <li> element from the <ul>
    };

    // Add event listener to the basket list
    basketItems.addEventListener('click', (event) => {
        if (event.target.tagName === 'BUTTON') {
            removeItem(event);
        }
    });
});
