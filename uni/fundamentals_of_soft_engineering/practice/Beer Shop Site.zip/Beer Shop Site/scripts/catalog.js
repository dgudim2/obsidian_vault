document.addEventListener('DOMContentLoaded', () => {
    const catalogItems = document.getElementById('catalog-items');
    const searchInput = document.getElementById('search-name');

    // Function to sort items
    const sortItems = (ascending) => {
        const itemsArray = Array.from(catalogItems.getElementsByTagName('li'));
        itemsArray.sort((a, b) => {
            const priceA = parseFloat(a.getAttribute('data-price'));
            const priceB = parseFloat(b.getAttribute('data-price'));
            return ascending ? priceA - priceB : priceB - priceA;
        });

        // Append sorted items back to the list
        itemsArray.forEach(item => catalogItems.appendChild(item));
    };

    // Function to filter items by name
    const filterByName = () => {
        const filter = searchInput.value.toLowerCase();
        const itemsArray = Array.from(catalogItems.getElementsByTagName('li'));
        itemsArray.forEach(item => {
            const name = item.getAttribute('data-name').toLowerCase();
            if (name.includes(filter)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    };

    // Event listeners for sorting buttons
    document.getElementById('sort-cheap-to-expensive').addEventListener('click', () => {
        sortItems(true);
    });

    document.getElementById('sort-expensive-to-cheap').addEventListener('click', () => {
        sortItems(false);
    });

    // Event listener for search input
    searchInput.addEventListener('input', filterByName);
});

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("bundle-form");
    const result = document.getElementById("bundle-result");

    form.addEventListener("submit", (event) => {
        event.preventDefault();

        const bundleName = document.getElementById("bundle-name").value.trim();
        const selectedBeers = Array.from(document.querySelectorAll("#bundle-options input:checked"));
        
        if (selectedBeers.length === 0) {
            result.textContent = "Please select at least one beer for your bundle.";
            return;
        }

        const beers = selectedBeers.map(beer => ({
            name: beer.value,
            price: parseFloat(beer.dataset.price)
        }));

        const totalPrice = beers.reduce((total, beer) => total + beer.price, 0);

        result.innerHTML = `
            <h3>${bundleName}</h3>
            <ul>
                ${beers.map(beer => `<li>${beer.name} - $${beer.price}</li>`).join("")}
            </ul>
            <strong>Total Price: $${totalPrice.toFixed(2)}</strong>
        `;
    });
});