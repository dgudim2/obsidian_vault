document.addEventListener("DOMContentLoaded", () => {
    const totalPriceElement = document.getElementById("total-price");
    const discountMessageElement = document.getElementById("discount-message");

    // Original price
    const originalPrice = 100.00; 

    // Get current time
    const now = new Date();
    const currentHour = now.getHours();

    let finalPrice = originalPrice;

    if (currentHour < 15) { // Before 3 PM
        const discount = originalPrice * 0.3; // 30% discount
        finalPrice = originalPrice - discount;
        discountMessageElement.textContent = `30% discount applied!`;
    } else {
        discountMessageElement.textContent = `No discount available right now.`;
    }

    // Update the displayed total price
    totalPriceElement.textContent = `$${finalPrice.toFixed(2)}`;
});